//Instance initialization
let system = new System();
let playerIcon = new Image();
//playerIcon.src = './assets/player_icon/0.jpg';
let player = new Player(
    10,
    0.5 * CANVAS_H,
    0,
    0,
    5,
    1,
    0,
    'scatter_shot',
    'Test Player',
    0,
    playerIcon
);
//Main loop
let MainLoopId = window.setInterval(mainLoop, dt);