window.tempName = '';   //Global variable for player name passing
function startGame(playerName){
    if(playerName === ''){
        alert('姓名不能为空！');
        return;
    }
    else{
        window.tempName = playerName;
        document.getElementById('info-area').remove();
        let DOM_playArea = document.body.appendChild(document.createElement('div'));
        DOM_playArea.id = 'play-area';
        DOM_playArea.align = 'center';
        let DOM_canvas = DOM_playArea.appendChild(document.createElement('canvas'));
        DOM_canvas.id = 'canvas';
        DOM_canvas.tabIndex = '0';
        DOM_canvas.width = '800';
        DOM_canvas.height = '500';
        document.body.setAttribute('onkeyup', 'ButtonUpCheck(event)');
        document.body.setAttribute('onkeydown', 'ButtonDownCheck(event)');
        let DOM_script_def = document.body.appendChild(document.createElement('script')),
            DOM_script_fun = document.body.appendChild(document.createElement('script')),
            DOM_script_main = document.body.appendChild(document.createElement('script'));
        DOM_script_def.src = './js/definations.js';
        DOM_script_fun.src = './js/functions.js';
        DOM_script_main.src = './js/main.js';
    }
}